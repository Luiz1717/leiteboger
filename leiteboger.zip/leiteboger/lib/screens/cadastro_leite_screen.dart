import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/leite_provider.dart';
import '../api_service.dart';


class CadastroLeiteScreen extends StatefulWidget {
  @override
  _CadastroLeiteScreenState createState() => _CadastroLeiteScreenState();
}

class _CadastroLeiteScreenState extends State<CadastroLeiteScreen> {
  final TextEditingController _quantidadeController = TextEditingController();
  final TextEditingController _motoristaController = TextEditingController();

  void _salvarCadastro() async {
    if (_motoristaController.text.isNotEmpty && _quantidadeController.text.isNotEmpty) {
      final provider = Provider.of<LeiteProvider>(context, listen: false);

      Map<String, dynamic> novoCadastro = {
        'motorista': _motoristaController.text,
        'quantidade': double.parse(_quantidadeController.text),
        'data': DateTime.now().toString(),
      };

      provider.adicionarLeite(novoCadastro);

      // Chamar API para enviar cadastro
      ApiService apiService = ApiService();
      await apiService.enviarCadastro(novoCadastro);

      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Por favor, preencha todos os campos!')),
      );
    }
    ElevatedButton(
      onPressed: () {
        Navigator.pushNamed(context, '/listagem');
      },
      child: Text('Ver Listagem'),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cadastrar Leite')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _motoristaController,
              decoration: InputDecoration(labelText: 'Nome do Motorista'),
            ),
            TextField(
              controller: _quantidadeController,
              decoration: InputDecoration(labelText: 'Quantidade de Leite (L)'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _salvarCadastro,
              child: Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }
}
