import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/leite_provider.dart';

class ListagemScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final listaLeite = Provider.of<LeiteProvider>(context).listaLeite;

    return Scaffold(
      appBar: AppBar(
        title: Text('Listagem de Leite Transportado'),
      ),
      body: listaLeite.isEmpty
          ? Center(child: Text('Nenhum registro encontrado.'))
          : ListView.builder(
        itemCount: listaLeite.length,
        itemBuilder: (context, index) {
          final registro = listaLeite[index];
          return Card(
            elevation: 3,
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blueAccent,
                child: Icon(
                  Icons.local_shipping,
                  color: Colors.blue,
                ),
              ),
              title: Text('Motorista: ${registro['motorista']}'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Data: ${registro['data']}'),
                  Text('Quantidade: ${registro['quantidade']} litros'),
                  if (registro.containsKey('localizacao'))
                    Text('Localização: ${registro['localizacao']}'),
                ],
              ),
              trailing: IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                onPressed: () {
                  _removerRegistro(context, index);
                },
              ),
            ),
          );
        },
      ),
    );
  }

  void _removerRegistro(BuildContext context, int index) {
    Provider.of<LeiteProvider>(context, listen: false).removerLeite(index);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Registro removido com sucesso!')),
    );
  }
}
