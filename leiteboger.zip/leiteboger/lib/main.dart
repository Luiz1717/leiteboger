import 'package:flutter/material.dart';
import 'package:leiteboger/screens/cadastro_leite_screen.dart';
import 'package:leiteboger/screens/resumo_screen.dart';
import 'package:provider/provider.dart';
import 'providers/leite_provider.dart';
import 'screens/listagem_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => LeiteProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(primarySwatch: Colors.blue),
        home: CadastroLeiteScreen(),
        routes: {
          '/listagem': (context) => ListagemScreen(),
          '/resumo': (context) => ResumoScreen(),
        },
      ),
    );
  }
}

